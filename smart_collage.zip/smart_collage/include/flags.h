#ifndef FLAGS_H
#define FLAGS_H

#include <string>
#include <vector>

// Struct chua toan bo thong so cau hinh cau lenh
struct ImageConfig {
    std::vector<std::string> inputs; // Danh sach anh dau vao
    std::string output_name = "collage_output"; // Mac dinh neu thieu -n
    std::string format = "png"; // Mac dinh neu thieu -f
    std::string color = "none"; // Mac dinh trong suot neu thieu -c
    std::string dest_dir = "."; // Mac dinh thu muc hien tai thieu -d
    std::string direction = "v";
    std::string spacing = "135";
};

// Ham boc tach tham so tu dong lenh
ImageConfig parse_arguments(int argc, char* argv[]);

#endif

