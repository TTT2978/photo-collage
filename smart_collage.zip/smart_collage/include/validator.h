#ifndef VALIDATOR_H
#define VALIDATOR_H

#include "flags.h"

namespace Validator {
    bool validate_files(const ImageConfig& config);
}

#endif

