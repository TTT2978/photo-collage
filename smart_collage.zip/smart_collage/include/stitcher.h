#ifndef STITCHER_H
#define STITCHER_H

#include "flags.h"

namespace Stitcher {
    void execute_stitch(const ImageConfig& config);
}

#endif

