#ifndef ERROR_HANDLER_H
#define ERROR_HANDLER_H

#include <string>

namespace ErrorHandler {
    void report_fatal(const std::string& message);
    void report_warning(const std::string& message);
    void report_success(const std::string& message);
    void report_info(const std::string& message);
}

#endif

