#include "stitcher.h"
#include "error_handler.h"
#include <sstream>
#include <cstdlib>

namespace Stitcher {
    void execute_stitch(const ImageConfig& config) {
        if (config.inputs.empty()) {
            ErrorHandler::report_fatal("No input images provided for stitching process.");
        }

        std::stringstream cmd;
        cmd << "magick ";

        // Nap toan bo danh sach anh vao lenh, boc ngoac kep tung file ngan chan loi cach khoang
        for (const auto& img : config.inputs) {
            cmd << "\"" << img << "\" ";
        }

        // Xu ly logic mau sac hoac tinh nang TB (Transparent + Blur) luu vet cho tuong lai
        if (config.color == "TB") {
            cmd << "-background none "; 
            // Luu y: logic add hieu ung blur tren vung nen none se duoc mo rong sau o day
        } else {
            cmd << "-background \"" << config.color << "\" ";
        }

        // Thiet lap cac thong so mac dinh (-smush doc 135px nhu phien ban truoc)
        cmd << "-auto-orient -gravity West ";
        if (config.direction == "h") {
            cmd << "+smush " << config.spacing << " ";
        } else {
            cmd << "-smush " << config.spacing << " ";
        }
        cmd << "-define png:compression-level=1 ";

        // Chuan hoa duong dan luu file xuat ra
        std::string final_output = config.dest_dir;
        if (!final_output.empty() && final_output.back() != '/') {
            final_output += "/";
        }
        final_output += config.output_name + "." + config.format;

        cmd << "\"" << final_output << "\"";

        ErrorHandler::report_info("Executing core ImageMagick pipeline...");
        
        // Goi shell thuc thi chuoi lenh he thong
        int result = std::system(cmd.str().c_str());
        if (result != 0) {
            ErrorHandler::report_fatal("ImageMagick process returned an error code: " + std::to_string(result));
        } else {
            ErrorHandler::report_success("Collage output successfully created at: " + final_output);
        }
    }
}

