#include "error_handler.h"
#include <iostream>
#include <cstdlib>

namespace ErrorHandler {
    void report_fatal(const std::string& message) {
        std::cerr << "[!] FATAL ERROR: " << message << std::endl;
        std::exit(1); // Dung toan bo tien trinh ngay lap tuc
    }

    void report_warning(const std::string& message) {
        std::cout << "[-] WARNING: " << message << std::endl;
    }

    void report_success(const std::string& message) {
        std::cout << "[+] SUCCESS: " << message << std::endl;
    }

    void report_info(const std::string& message) {
        std::cout << "[>] INFO: " << message << std::endl;
    }
}

