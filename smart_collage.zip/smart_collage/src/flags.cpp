#include <iostream>
#include <cstdlib>
#include "flags.h"

ImageConfig parse_arguments(int argc, char* argv[]) {
    ImageConfig config;
    
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        
        if (arg == "-h" || arg == "--help") {
            std::cout << "--- SMART PIXEL COLLAGE CLI ---\nUsage:\n  img [input_files...] [options]\n\nOptions:\n  -n <name>      Output file name (default: collage_output)\n  -f <format>    Output format (jpg, png, webp) (default: png)\n  -c <color/TB>  Background color or TB (default: none)\n  -d <path>      Destination directory path (default: .)\n  -s <number>    Spacing (default: 135)\n  -dir <v|h>     Direction: v (vertical), h (horizontal) (default: v)\n  -h, --help     Show this help message\n";
            std::exit(0);
        } else if (arg == "-n" && i + 1 < argc) {
            config.output_name = argv[++i];
        } else if (arg == "-f" && i + 1 < argc) {
            config.format = argv[++i];
        } else if (arg == "-c" && i + 1 < argc) {
            config.color = argv[++i];
        } else if (arg == "-d" && i + 1 < argc) {
            config.dest_dir = argv[++i];
        } else if (arg == "-s" && i + 1 < argc) {
            config.spacing = argv[++i];
        } else if (arg == "-dir" && i + 1 < argc) {
            config.direction = argv[++i];
        } else if (arg[0] == '-') {
            // Bo qua hoac ghi nhan cac flag khong hop le cho tinh nang tuong lai
        } else {
            // Neu khong phai flag va gia tri di kem, thi no la duong dan file anh
            if (!arg.empty()) {
                config.inputs.push_back(arg);
            }
        }
    }
    return config;
}

