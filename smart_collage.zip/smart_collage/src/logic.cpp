#include <iostream>
#include <string>
#include "../include/flags.h"
#include "../include/error_handler.h"
#include "../include/stitcher.h"
#include "../include/validator.h"

int main(int argc, char* argv[]) {
    // 1. Kiem tra xem co truyen gi vao khong
    if (argc < 2) {
        std::cout << "--- SMART PIXEL COLLAGE CLI ---" << std::endl;
        ErrorHandler::report_info("Usage: img <img1> <img2> ... [-n name] [-f format] [-c color/TB] [-d path]");
        ErrorHandler::report_fatal("No arguments provided. Exit 1.");
    }

    ErrorHandler::report_info("Initializing Core Logic...");

    // 2. Goi module Flags de boc tach toan bo chuoi alias
    ImageConfig config = parse_arguments(argc, argv);

    // 3. Kiem tra so luong anh sau khi loc flag
    if (config.inputs.empty()) {
        ErrorHandler::report_fatal("Arguments parsed, but no input images detected.");
    }

    ErrorHandler::report_info("Parsed successfully. Target images count: " + std::to_string(config.inputs.size()));

    if (!Validator::validate_files(config)) {
        ErrorHandler::report_fatal("Quá trình dừng lại do phát hiện đường dẫn ảnh không hợp lệ.");
    }

    // 4. Chuyen giao quyen dieu hanh cho module Stitcher de bat dau ghep
    Stitcher::execute_stitch(config);

    return 0;
}

