#include "validator.h"
#include "error_handler.h"
#include <fstream>

namespace Validator {
    bool validate_files(const ImageConfig& config) {
        for (const auto& path : config.inputs) {
            std::ifstream file(path);
            if (!file.good()) {
                ErrorHandler::report_warning("File không tồn tại hoặc sai đường dẫn: " + path);
                return false;
            }
        }
        return true;
    }
}

